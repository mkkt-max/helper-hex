package com.hexhelper.core;

/** Классификация цвета плиток по оттенку (HSV). Тёмные боковые грани сохраняют оттенок. */
public final class HexColor {
    public static final int NONE = -1;
    public static final int RED = 0, ORANGE = 1, YELLOW = 2, GREEN = 3,
            CYAN = 4, BLUE = 5, VIOLET = 6, MAGENTA = 7;
    public static final String[] NAMES = {"R", "O", "Y", "G", "C", "B", "V", "M"};
    /** Цвета для отладочной отрисовки (ARGB). */
    public static final int[] ARGB = {
            0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
            0xFF26C6DA, 0xFF1E5AE0, 0xFF7E57C2, 0xFFD81B9B};

    private HexColor() {}

    public static int lum(int argb) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        return (int) (0.3 * r + 0.59 * g + 0.11 * b);
    }

    /** Серый пиксель (пустая клетка, замок, фон): низкая насыщенность. */
    public static boolean isGray(int argb) {
        float[] hsv = hsv(argb);
        return hsv[1] < 0.12f;
    }

    /** Возвращает класс цвета или NONE, если пиксель не похож на плитку. */
    public static int classify(int argb) {
        float[] hsv = hsv(argb);
        float s = hsv[1], v = hsv[2], h = hsv[0];
        if (s < 0.40f || v < 0.10f) return NONE;
        if (h >= 345f || h < 15f) return RED;
        if (h < 34f) return ORANGE;
        if (h < 70f) return YELLOW;
        if (h < 160f) return GREEN;
        if (h < 200f) return CYAN;
        if (h < 250f) return BLUE;
        if (h < 282f) return VIOLET;
        return MAGENTA;
    }

    /** {hue 0..360, saturation 0..1, value 0..1} */
    static float[] hsv(int argb) {
        float r = ((argb >> 16) & 255) / 255f;
        float g = ((argb >> 8) & 255) / 255f;
        float b = (argb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h;
        if (d == 0) h = 0;
        else if (max == r) h = 60f * (((g - b) / d) % 6f);
        else if (max == g) h = 60f * (((b - r) / d) + 2f);
        else h = 60f * (((r - g) / d) + 4f);
        if (h < 0) h += 360f;
        float s = max == 0 ? 0 : d / max;
        return new float[]{h, s, max};
    }
}
