package com.hexhelper.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import com.hexhelper.core.HexColor;
import com.hexhelper.core.Solver;
import com.hexhelper.core.Vision;

/** Прозрачный слой поверх игры: стрелки, номера ходов и отладочная сетка. Касания не перехватывает. */
public class OverlayView extends View {
    private static final int[] STEP_COLORS = {0xFF00E676, 0xFFFFEA00, 0xFFFF9100};

    private Vision.Scene scene;
    private Solver.Plan plan;
    private Vision.Calib calib = new Vision.Calib();
    private int screenW = 1080;
    private boolean debug;
    private String message = "";

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;

    public OverlayView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        ring.setStyle(Paint.Style.STROKE);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setResult(Vision.Scene scene, Solver.Plan plan, Vision.Calib calib, int screenW,
                          boolean debug, String message) {
        this.scene = scene; this.plan = plan; this.calib = calib;
        this.screenW = screenW; this.debug = debug; this.message = message;
        postInvalidate();
    }

    public void clear() { scene = null; plan = null; message = ""; postInvalidate(); }

    private float sx(double refX) { return (float) Vision.toScreenX(refX, screenW, calib); }
    private float sy(double refY) { return (float) Vision.toScreenY(refY, screenW, calib); }
    private float unit() { return (float) (screenW / Vision.REF_W * calib.scale); }

    @Override
    protected void onDraw(Canvas cv) {
        // окно может начинаться не с (0,0) экрана (вырез, статус-бар) — компенсируем
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        cv.translate(-loc[0], -loc[1]);
        float u = unit();

        if (debug && scene != null) drawDebug(cv, u);

        if (plan != null && scene != null && !plan.moves.isEmpty()) {
            for (int i = plan.moves.size() - 1; i >= 0; i--) drawMove(cv, i, u);
        }
        if (!message.isEmpty()) drawBanner(cv, u);
    }

    private void drawMove(Canvas cv, int i, float u) {
        Solver.Move m = plan.moves.get(i);
        Vision.Cell cell = scene.playable.get(m.cell);
        int col = STEP_COLORS[Math.min(i, STEP_COLORS.length - 1)];
        float tx = sx(cell.x), ty = sy(cell.y);
        float fx = sx(scene.handX[m.slot]), fy = sy(Vision.HAND_CENTER_Y);

        // стрелка из руки в клетку
        line.setColor(col);
        line.setStrokeWidth((i == 0 ? 9f : 5f) * dp * 0.8f);
        line.setPathEffect(i == 0 ? null : new DashPathEffect(new float[]{26, 18}, 0));
        float dx = tx - fx, dy = ty - fy;
        float len = (float) Math.hypot(dx, dy);
        if (len > 1) {
            float ux = dx / len, uy = dy / len;
            float ex = tx - ux * 60 * u, ey = ty - uy * 60 * u;
            float sx0 = fx + ux * 60 * u, sy0 = fy + uy * 60 * u;
            cv.drawLine(sx0, sy0, ex, ey, line);
            Path head = new Path();
            float hs = 34 * u;
            head.moveTo(ex + ux * hs * 0.4f, ey + uy * hs * 0.4f);
            head.lineTo(ex - ux * hs + uy * hs * 0.7f, ey - uy * hs - ux * hs * 0.7f);
            head.lineTo(ex - ux * hs - uy * hs * 0.7f, ey - uy * hs + ux * hs * 0.7f);
            head.close();
            fill.setColor(col);
            fill.setStyle(Paint.Style.FILL);
            cv.drawPath(head, fill);
        }
        // кольцо на целевой клетке и номер хода
        ring.setColor(col);
        ring.setStrokeWidth(8 * u);
        cv.drawCircle(tx, ty, 78 * u, ring);
        drawBadge(cv, tx + 70 * u, ty - 70 * u, String.valueOf(i + 1), col, u);
        // номер над стопкой в руке
        drawBadge(cv, fx, fy - 130 * u, String.valueOf(i + 1), col, u);
    }

    private void drawBadge(Canvas cv, float x, float y, String s, int col, float u) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(col);
        cv.drawCircle(x, y, 30 * u, fill);
        text.setColor(Color.BLACK);
        text.setTextSize(38 * u);
        cv.drawText(s, x, y + 13 * u, text);
    }

    private void drawBanner(Canvas cv, float u) {
        text.setTextSize(34 * u);
        text.setTextAlign(Paint.Align.LEFT);
        float pad = 18 * u, w = text.measureText(message) + pad * 2;
        float x = 24 * u, y = 230 * u;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xCC000000);
        cv.drawRoundRect(x, y, x + w, y + 34 * u + pad * 2, 16 * u, 16 * u, fill);
        text.setColor(Color.WHITE);
        cv.drawText(message, x + pad, y + pad + 28 * u, text);
        text.setTextAlign(Paint.Align.CENTER);
    }

    private void drawDebug(Canvas cv, float u) {
        text.setTextSize(30 * u);
        for (Vision.Cell c : scene.grid) {
            float x = sx(c.x), y = sy(c.y);
            String t;
            int col;
            if (c.type == Vision.T_EMPTY) { t = "·"; col = Color.GREEN; }
            else if (c.type == Vision.T_LOCKED) { t = "x"; col = Color.RED; }
            else {
                StringBuilder sb = new StringBuilder();
                for (int v : c.stack) sb.append(HexColor.NAMES[v]);
                t = sb.toString() + " (" + c.stack.length + ")";
                col = Color.WHITE;
            }
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(0x99000000);
            float tw = text.measureText(t);
            cv.drawRect(x - tw / 2 - 6, y - 24 * u, x + tw / 2 + 6, y + 14 * u, fill);
            text.setColor(col);
            cv.drawText(t, x, y + 8 * u, text);
        }
        for (int i = 0; i < scene.hand.length; i++) {
            StringBuilder sb = new StringBuilder();
            for (int v : scene.hand[i]) sb.append(HexColor.NAMES[v]);
            text.setColor(Color.WHITE);
            cv.drawText(sb.toString(), sx(scene.handX[i]), sy(Vision.HAND_CENTER_Y) + 140 * u, text);
        }
    }
}
