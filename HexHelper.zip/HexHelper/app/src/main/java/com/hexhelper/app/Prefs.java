package com.hexhelper.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.hexhelper.core.Vision;

/** Настройки калибровки, правил и поиска. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) { sp = c.getSharedPreferences("hexhelper", Context.MODE_PRIVATE); }

    public int scalePct() { return sp.getInt("scalePct", 100); }          // 90..110
    public int offX() { return sp.getInt("offX", 0); }                    // опорные px
    public int offY() { return sp.getInt("offY", 0); }
    public int clearN() { return sp.getInt("clearN", 10); }               // сколько плиток сгорает
    public int ptsPerTile() { return sp.getInt("pts", 10); }              // очков за сгоревшую плитку
    public int budgetSec() { return sp.getInt("budgetSec", 3); }          // время расчёта
    public int rounds() { return sp.getInt("rounds", 4); }                // раундов вперёд
    public int scoreTarget() { return sp.getInt("target", 450); }         // число у сундука
    public String lockPricesText() { return sp.getString("locks", "200,350"); }
    public boolean debug() { return sp.getBoolean("debug", false); }
    public boolean auto() { return sp.getBoolean("auto", true); }

    public void putInt(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public void putString(String k, String v) { sp.edit().putString(k, v).apply(); }

    public int[] lockPrices() {
        String[] parts = lockPricesText().split("[^0-9]+");
        int cnt = 0;
        int[] tmp = new int[parts.length];
        for (String p : parts) {
            if (p.isEmpty()) continue;
            try { tmp[cnt++] = Integer.parseInt(p); } catch (NumberFormatException ignored) {}
        }
        int[] r = new int[cnt];
        System.arraycopy(tmp, 0, r, 0, cnt);
        return r;
    }

    public Vision.Calib calib() {
        Vision.Calib c = new Vision.Calib();
        c.scale = scalePct() / 100.0;
        c.offX = offX();
        c.offY = offY();
        c.lockPrices = lockPrices();
        c.scoreTarget = scoreTarget();
        c.ptsPerTile = ptsPerTile();
        return c;
    }
}
