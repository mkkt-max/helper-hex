package com.hexhelper.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.hexhelper.core.Vision;

/** Настройки калибровки и правил. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) { sp = c.getSharedPreferences("hexhelper", Context.MODE_PRIVATE); }

    public int scalePct() { return sp.getInt("scalePct", 100); }          // 90..110
    public int offX() { return sp.getInt("offX", 0); }                    // -100..100 (опорные px)
    public int offY() { return sp.getInt("offY", 0); }
    public int clearN() { return sp.getInt("clearN", 10); }               // сколько плиток сгорает
    public boolean debug() { return sp.getBoolean("debug", false); }

    public void putInt(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    public Vision.Calib calib() {
        Vision.Calib c = new Vision.Calib();
        c.scale = scalePct() / 100.0;
        c.offX = offX();
        c.offY = offY();
        return c;
    }
}
