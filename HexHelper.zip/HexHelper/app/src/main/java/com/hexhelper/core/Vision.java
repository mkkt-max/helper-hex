package com.hexhelper.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Распознавание поля по скриншоту. Все координаты заданы в «опорной» системе 1080 px по ширине
 * (так откалиброваны скриншоты) и пересчитываются в реальный экран.
 *
 * Геометрия: шестиугольники с плоской вершиной, колонки через 174.25 px, строки через 87.5 px
 * (соседняя колонка сдвинута на пол-клетки). Слой стопки — 10 px по вертикали, стопки растут вверх.
 */
public final class Vision {
    public static final double REF_W = 1080;

    // сетка поля
    static final double GX0 = 190, DX = 174.25, GY0 = 590, DY = 87.5;
    static final int COLS = 5;
    static final double Y_MIN = 430, Y_MAX = 1480;
    // клетки в руке
    public static final double HAND_BASE_Y = 1833;      // нижний край основания стопки в руке
    public static final double HAND_CENTER_Y = 1730;
    // стопка на поле: нижний край основания = центр клетки + 81
    static final double BOARD_BASE = 81;
    static final double LAYER = 10;       // толщина одного слоя
    static final double FACE_H = 172;     // высота верхней грани вместе с первым слоем
    static final double FACE_MIN_RUN = 160;

    public static final int T_NONE = 0, T_EMPTY = 1, T_LOCKED = 2, T_STACK = 3;

    public static final class Calib {
        public double scale = 1.0;   // множитель масштаба
        public double offX = 0, offY = 0;  // сдвиг в опорных пикселях
        public int[] lockPrices = {200, 350};   // цены закрытых клеток: слева направо, сверху вниз
        public int scoreTarget = 450;           // число у сундука (полная полоска)
        public int ptsPerTile = 10;             // очков за каждую сгоревшую плитку
    }

    public static final class Cell {
        public int id = -1, j, k;
        public double x, y;          // центр клетки (опорные px)
        public int type;
        public int[] stack = new int[0];
    }

    public static final class Scene {
        public final List<Cell> grid = new ArrayList<>();     // все распознанные точки решётки (кроме NONE)
        public final List<Cell> playable = new ArrayList<>(); // пустые + занятые; индекс = id в Board
        public Board board;
        public int score = -1;                                // очки по полоске прогресса (-1 — не прочитано)
        public int[][] hand = new int[0][];                   // стопки в руке (слева направо)
        public double[] handX = new double[0];                // центры этих стопок (опорные px)
    }

    private final int[] px;
    private final int w, h;
    private final double s, ox, oy;

    private Calib calib;

    private Vision(int[] px, int w, int h, Calib c) {
        this.px = px; this.w = w; this.h = h; this.calib = c;
        this.s = (w / REF_W) * c.scale;
        this.ox = c.offX; this.oy = c.offY;
    }

    public static Scene analyze(int[] pixels, int width, int height, Calib calib) {
        return new Vision(pixels, width, height, calib).run();
    }

    // ---- преобразования координат (для оверлея) ----
    public static double toScreenX(double refX, int w, Calib c) { return (refX + c.offX) * (w / REF_W) * c.scale; }
    public static double toScreenY(double refY, int w, Calib c) { return (refY + c.offY) * (w / REF_W) * c.scale; }

    private int at(double xr, double yr) {
        int x = (int) Math.round((xr + ox) * s);
        int y = (int) Math.round((yr + oy) * s);
        if (x < 0) x = 0; if (x >= w) x = w - 1;
        if (y < 0) y = 0; if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    private Scene run() {
        Scene sc = new Scene();
        // 1) решётка: допустимы только точки с (j + k) чётным
        int kMin = (int) Math.floor((Y_MIN - GY0) / DY), kMax = (int) Math.ceil((Y_MAX - GY0) / DY);
        Cell[][] g = new Cell[COLS][kMax - kMin + 1];
        for (int j = 0; j < COLS; j++) {
            for (int k = kMin; k <= kMax; k++) {
                if (((j + k) & 1) != 0) continue;
                double cx = GX0 + DX * j, cy = GY0 + DY * k;
                if (cy < Y_MIN || cy > Y_MAX) continue;
                Cell c = new Cell();
                c.j = j; c.k = k; c.x = cx; c.y = cy;
                c.type = classifyCell(cx, cy);
                if (c.type != T_NONE) { sc.grid.add(c); g[j][k - kMin] = c; }
            }
        }
        // 2) чтение стопок: сначала нижние клетки колонки (они могут перекрывать верхние)
        List<Cell> byY = new ArrayList<>(sc.grid);
        byY.sort((a, b) -> Double.compare(b.y, a.y));
        for (Cell c : byY) {
            if (c.type != T_STACK) continue;
            double base = c.y + BOARD_BASE;
            double y0 = base;
            Cell low = (c.k + 2 - kMin < g[c.j].length) ? g[c.j][c.k + 2 - kMin] : null;
            if (low != null && low.type == T_STACK && low.stack.length > 1) {
                double tLow = low.y - 86 - LAYER * (low.stack.length - 1);
                y0 = Math.min(base, tLow - 14);
            }
            c.stack = readStack(c.x, base, y0);
            if (c.stack.length == 0) c.type = T_EMPTY;
        }
        // 3) клетки (пустые, занятые и закрытые) и соседство. Закрытые тоже входят в поле,
        //    чтобы в расчёте они открывались, когда набрано достаточно очков.
        for (Cell c : sc.grid) {
            if (c.type == T_EMPTY || c.type == T_STACK || c.type == T_LOCKED) { c.id = sc.playable.size(); sc.playable.add(c); }
        }
        int n = sc.playable.size();
        int[][] nbr = new int[n][];
        int[][] d = {{0, -2}, {0, 2}, {1, -1}, {1, 1}, {-1, -1}, {-1, 1}};
        for (Cell c : sc.playable) {
            List<Integer> l = new ArrayList<>();
            for (int[] o : d) {
                int jj = c.j + o[0], kk = c.k + o[1];
                if (jj < 0 || jj >= COLS || kk - kMin < 0 || kk - kMin >= g[jj].length) continue;
                Cell nb = g[jj][kk - kMin];
                if (nb != null && nb.id >= 0) l.add(nb.id);
            }
            nbr[c.id] = new int[l.size()];
            for (int i = 0; i < l.size(); i++) nbr[c.id][i] = l.get(i);
        }
        sc.board = new Board(n, nbr);
        sc.score = readScore();
        sc.board.score = Math.max(0, sc.score);
        sc.board.pts = calib.ptsPerTile;
        List<Cell> locked = new ArrayList<>();
        for (Cell c : sc.playable) {
            if (c.type == T_STACK) sc.board.setStack(c.id, c.stack);
            else if (c.type == T_LOCKED) locked.add(c);
        }
        locked.sort((a, b) -> a.x != b.x ? Double.compare(a.x, b.x) : Double.compare(a.y, b.y));
        // цены, которые уже достигнуты, относятся к открытым клеткам; оставшиеся — по порядку закрытым
        int[] prices = calib.lockPrices == null ? new int[0] : calib.lockPrices.clone();
        java.util.Arrays.sort(prices);
        List<Integer> remaining = new ArrayList<>();
        for (int p : prices) if (p > sc.board.score) remaining.add(p);
        for (int i = 0; i < locked.size(); i++)
            sc.board.price[locked.get(i).id] = i < remaining.size() ? remaining.get(i) : Board.NEVER;
        // 4) стопки в руке: после использования оставшиеся сдвигаются к центру,
        //    поэтому ищем их по цветным участкам строки над основанием
        List<double[]> found = new ArrayList<>();
        double rowY = HAND_BASE_Y - 40;
        double runStart = -1, lastColored = -1;
        for (double x = 40; x <= REF_W - 40 + 1; x += 3) {
            boolean col = x <= REF_W - 40 && HexColor.classify(at(x, rowY)) != HexColor.NONE;
            if (col) {
                if (runStart < 0) runStart = x;
                lastColored = x;
            } else if (runStart >= 0 && x - lastColored > 12) {
                if (lastColored - runStart >= 80) found.add(new double[]{(runStart + lastColored) / 2});
                runStart = -1;
            }
        }
        List<int[]> hs = new ArrayList<>();
        List<Double> hx = new ArrayList<>();
        for (double[] f : found) {
            if (hs.size() == 3) break;
            int[] st = readStack(f[0], HAND_BASE_Y, HAND_BASE_Y);
            if (st.length > 0) { hs.add(st); hx.add(f[0]); }
        }
        sc.hand = hs.toArray(new int[0][]);
        sc.handX = new double[hx.size()];
        for (int i = 0; i < sc.handX.length; i++) sc.handX[i] = hx.get(i);
        return sc;
    }

    /** Очки по заполнению полоски прогресса: золотая часть от x=52 растёт на (843 / цель) px за очко. */
    private int readScore() {
        double end = -1;
        for (double yRef : new double[]{288, 306}) {
            double last = -1;
            int gap = 0;
            boolean started = false;
            for (double x = 40; x <= 890; x += 1) {
                if (HexColor.isGold(at(x, yRef))) { started = true; last = x; gap = 0; }
                else if (started && ++gap > 40) break;
            }
            if (last > end) end = last;
        }
        if (end < 0) return -1;
        double s = (end - 52) / (843.0 / Math.max(1, calib.scoreTarget));
        return s < 4 ? 0 : (int) Math.round(s);
    }

    private int classifyCell(double cx, double cy) {
        // стопка (любой высоты) закрашивает центр клетки и по вертикали выше и ниже него;
        // чужие стопки у пустой клетки сюда не доходят
        if (HexColor.classify(at(cx, cy - 20)) != HexColor.NONE
                && HexColor.classify(at(cx, cy + 40)) != HexColor.NONE) return T_STACK;
        boolean gray = false;
        double[][] probe = {{cx, cy - 40}, {cx - 70, cy}, {cx + 70, cy}, {cx, cy + 50}};
        for (double[] q : probe) {
            int p = at(q[0], q[1]);
            if (HexColor.isGray(p) && HexColor.lum(p) >= 55) { gray = true; break; }
        }
        if (!gray) return T_NONE;
        // серая клетка: пустая или закрытая (замок + цена — тёмные пиксели)
        int dark = 0;
        for (int y = (int) cy - 65; y <= cy + 45; y += 3)
            for (int x = (int) cx - 45; x <= cx + 45; x += 3)
            {
                int q = at(x, y);   // считаем только серые тёмные пиксели: замок и цена
                if (HexColor.isGray(q) && HexColor.lum(q) < 95) dark++;
            }
        return dark >= 40 ? T_LOCKED : T_EMPTY;
    }

    /**
     * Читает стопку снизу вверх по вертикали x = cx от y0 вверх по цветовым «отрезкам».
     * Основание стопки — base; если часть основания закрыта соседом, y0 выше base,
     * и скрытые слои считаются цветом первого видимого отрезка.
     */
    private int[] readStack(double cx, double base, double y0) {
        List<int[]> runs = new ArrayList<>();
        int cur = -2, curLen = 0, pending = 0;
        for (int i = 0; i < 420; i++) {
            int c = HexColor.classify(at(cx, y0 - i));
            if (c == HexColor.NONE) {
                if (++pending > 6) break;
                continue;
            }
            if (c == cur) { curLen += pending + 1; pending = 0; continue; }
            if (cur != -2) { curLen += pending; runs.add(new int[]{cur, curLen}); }
            cur = c; curLen = 1; pending = 0;
        }
        if (cur != -2) runs.add(new int[]{cur, curLen});
        if (runs.isEmpty()) return new int[0];

        // убираем шум: короткие отрезки (< 7 px) вливаем в предыдущий, одинаковые соседние склеиваем
        List<int[]> sm = new ArrayList<>();
        for (int[] r : runs) {
            if (r[1] < 7 && !sm.isEmpty()) { sm.get(sm.size() - 1)[1] += r[1]; continue; }
            if (!sm.isEmpty() && sm.get(sm.size() - 1)[0] == r[0]) { sm.get(sm.size() - 1)[1] += r[1]; continue; }
            sm.add(new int[]{r[0], r[1]});
        }
        sm.get(0)[1] += (int) Math.round(base - y0);   // скрытые слои

        // лицевая грань — первый отрезок длиннее FACE_MIN_RUN; всё выше — чужая стопка
        int f = sm.size() - 1;
        for (int i = 0; i < sm.size(); i++) if (sm.get(i)[1] >= FACE_MIN_RUN) { f = i; break; }

        List<Integer> out = new ArrayList<>();
        for (int i = 0; i <= f; i++) {
            int len = sm.get(i)[1];
            int cnt;
            if (i == f) cnt = (int) Math.floor((len - FACE_H) / LAYER + 0.8);
            else cnt = (int) Math.round(len / LAYER);
            if (cnt < 1) cnt = 1;
            if (cnt > 24) cnt = 24;
            for (int q = 0; q < cnt; q++) out.add(sm.get(i)[0]);
        }
        int[] res = new int[out.size()];
        for (int i = 0; i < res.length; i++) res[i] = out.get(i);
        return res;
    }
}
