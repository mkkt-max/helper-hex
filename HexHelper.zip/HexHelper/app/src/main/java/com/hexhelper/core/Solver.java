package com.hexhelper.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SplittableRandom;

/**
 * Двухэтапный поиск.
 * 1) Перебираются ВСЕ порядки и клетки для стопок из руки; лучшие topK вариантов по статической оценке
 *    проходят дальше. Учитываются слияния, сгорание, очки и открытие закрытых клеток.
 * 2) Каждый вариант проверяется «взглядом вперёд»: после него в руке появляются случайные новые стопки
 *    (по палитре цветов на поле), и дальше играется жадная политика на несколько раундов.
 *    Варианты получают прогоны по очереди, слабые отсеиваются (successive halving), пока не выйдет
 *    бюджет времени. На телефоне это сотни тысяч — миллионы симулированных постановок.
 */
public final class Solver {
    public static final class Move {
        public final int slot;   // индекс стопки в руке
        public final int cell;   // индекс клетки на поле
        Move(int slot, int cell) { this.slot = slot; this.cell = cell; }
    }

    public static final class Plan {
        public final List<Move> moves = new ArrayList<>();
        public double score = Double.NEGATIVE_INFINITY;  // среднее значение прогонов
        public int cleared;                              // сгорит плиток этими ходами
        public long simulated;                           // сколько постановок просчитано
        public int candidates, rollouts;
        public boolean unlocks;                          // эти ходы открывают закрытую клетку
    }

    public static final class Params {
        public int clearN = 10;
        public long budgetMs = 3000;
        public int topK = 24;
        public int rounds = 4;        // сколько будущих раундов (по 3 стопки) просматривать
        public double gamma = 0.9;
    }

    private static final class Cand {
        int[] slots, cells;
        Board board;
        int cleared;
        double stat;
        double sum;
        int cnt;
        boolean unlocks;
        double avg() { return cnt == 0 ? Double.NEGATIVE_INFINITY : sum / cnt; }
    }

    private final Params prm;
    private final int[][] pieces;
    private final int total;
    private final List<Cand> top = new ArrayList<>();
    private final Board[] scratch;
    private final int[] curSlot, curCell;
    private final boolean[] used;

    private Solver(int[][] pieces, Params p, Board root) {
        this.pieces = pieces; this.prm = p; this.total = pieces.length;
        scratch = new Board[total + 1];
        for (int i = 0; i <= total; i++) scratch[i] = root.copy();
        curSlot = new int[total]; curCell = new int[total];
        used = new boolean[total];
    }

    public static Plan solve(Board root, int[][] pieces, Params p) {
        Plan plan = new Plan();
        if (pieces.length == 0) return plan;
        Solver s = new Solver(pieces, p, root);
        s.scratch[0].copyFrom(root);
        s.dfs(0, 0);
        if (s.top.isEmpty()) return plan;
        long t0 = System.nanoTime();
        s.refine(root, t0);
        Cand best = null;
        for (Cand c : s.top) {
            if (best == null || c.avg() > best.avg() || (best.cnt == 0 && c.stat > best.stat)) best = c;
        }
        if (best.cnt == 0) for (Cand c : s.top) if (c.stat > best.stat) best = c;
        for (int i = 0; i < best.slots.length; i++) plan.moves.add(new Move(best.slots[i], best.cells[i]));
        plan.score = best.cnt > 0 ? best.avg() : best.stat;
        plan.cleared = best.cleared;
        plan.unlocks = best.unlocks;
        plan.candidates = s.top.size();
        long sim = 0;
        for (Board b : s.scratch) sim += b.simCount;
        plan.simulated = sim + s.rolloutSims;
        plan.rollouts = s.rolloutCount;
        return plan;
    }

    // ---------- этап 1: полный перебор рук ----------

    private void dfs(int depth, int cleared) {
        Board cur = scratch[depth];
        boolean any = false;
        for (int p = 0; p < total; p++) {
            if (used[p]) continue;
            for (int c = 0; c < cur.n; c++) {
                if (!cur.canPlace(c)) continue;
                any = true;
                Board nb = scratch[depth + 1];
                nb.copyFrom(cur);
                int cl = nb.place(c, pieces[p], prm.clearN);
                used[p] = true; curSlot[depth] = p; curCell[depth] = c;
                if (depth + 1 == total) offer(nb, cleared + cl, total);
                else dfs(depth + 1, cleared + cl);
                used[p] = false;
            }
        }
        if (!any && depth > 0) {   // поле заполнено раньше, чем кончились стопки — тупик
            offer(cur, cleared, depth);
        }
    }

    private void offer(Board b, int cleared, int len) {
        double stat = 100.0 * cleared + staticEval(b, prm.clearN);
        if (len < total) stat -= 2000.0 * (total - len);
        if (top.size() >= prm.topK) {
            int worst = 0;
            for (int i = 1; i < top.size(); i++) if (top.get(i).stat < top.get(worst).stat) worst = i;
            if (top.get(worst).stat >= stat) return;
            top.remove(worst);
        }
        Cand c = new Cand();
        c.slots = new int[len]; c.cells = new int[len];
        System.arraycopy(curSlot, 0, c.slots, 0, len);
        System.arraycopy(curCell, 0, c.cells, 0, len);
        c.board = b.copy();
        c.cleared = cleared;
        c.stat = stat;
        // открылась ли закрытая клетка
        Board root0 = scratch[0];
        for (int i = 0; i < b.n; i++) if (root0.price[i] != 0 && b.price[i] == 0) { c.unlocks = true; break; }
        top.add(c);
    }

    // ---------- этап 2: прогоны вперёд ----------

    private long rolloutSims;
    private int rolloutCount;

    private void refine(Board root, long t0) {
        long deadline = t0 + prm.budgetMs * 1_000_000L;
        SplittableRandom rnd = new SplittableRandom(System.nanoTime());
        double[] weights = palette(root);
        Board a = root.copy(), trial = root.copy();
        List<Cand> active = new ArrayList<>(top);
        int pass = 0;
        while (System.nanoTime() < deadline) {
            for (Cand c : active) {
                if (c.stat < -1000 && active.size() > 1) continue;   // тупики не уточняем
                for (int b = 0; b < 4; b++) {
                    if (System.nanoTime() >= deadline) break;
                    c.sum += rollout(c, rnd, weights, a, trial);
                    c.cnt++;
                    rolloutCount++;
                }
            }
            pass++;
            if (active.size() > 3 && pass % 4 == 0) {
                Collections.sort(active, (x, y) -> Double.compare(y.avg(), x.avg()));
                int keep = Math.max(3, (int) Math.ceil(active.size() * 0.6));
                active = new ArrayList<>(active.subList(0, keep));
            }
        }
        rolloutSims = a.simCount + trial.simCount;
    }

    private double rollout(Cand cand, SplittableRandom rnd, double[] w, Board a, Board trial) {
        a.copyFrom(cand.board);
        double value = 100.0 * cand.cleared;
        double disc = 1.0;
        int[][] hand = new int[3][];
        boolean[] u = new boolean[3];
        for (int r = 0; r < prm.rounds; r++) {
            for (int i = 0; i < 3; i++) { hand[i] = randomPiece(rnd, w); u[i] = false; }
            double roundClear = 0;
            for (int t = 0; t < 3; t++) {
                double best = Double.NEGATIVE_INFINITY;
                int bp = -1, bc = -1;
                for (int p = 0; p < 3; p++) {
                    if (u[p]) continue;
                    for (int c = 0; c < a.n; c++) {
                        if (!a.canPlace(c)) continue;
                        trial.copyFrom(a);
                        int cl = trial.place(c, hand[p], prm.clearN);
                        double v = 100.0 * cl + staticEval(trial, prm.clearN);
                        if (v > best) { best = v; bp = p; bc = c; }
                    }
                }
                if (bp < 0) return value - 3000.0 * disc;     // нет клеток — проигрыш
                roundClear += a.place(bc, hand[bp], prm.clearN);
                u[bp] = true;
            }
            disc *= prm.gamma;
            value += disc * 100.0 * roundClear;
        }
        return value + disc * staticEval(a, prm.clearN);
    }

    /** Веса цветов для будущих стопок: чаще те цвета, что уже есть на поле и в руке. */
    private double[] palette(Board root) {
        double[] w = new double[8];
        for (int c = 0; c < root.n; c++) for (int i = 0; i < root.len[c]; i++) w[root.at(c, i)] += 1;
        for (int[] p : pieces) for (int v : p) w[v] += 1;
        double sum = 0;
        for (double v : w) sum += v;
        if (sum == 0) for (int i = 0; i < 8; i++) w[i] = 1;
        return w;
    }

    private static int pickColor(SplittableRandom rnd, double[] w) {
        double sum = 0;
        for (double v : w) sum += v;
        double x = rnd.nextDouble() * sum;
        for (int i = 0; i < w.length; i++) { x -= w[i]; if (x <= 0 && w[i] > 0) return i; }
        for (int i = w.length - 1; i >= 0; i--) if (w[i] > 0) return i;
        return 0;
    }

    private static int[] randomPiece(SplittableRandom rnd, double[] w) {
        int total = 4 + rnd.nextInt(3);                     // 4..6 плиток
        int c1 = pickColor(rnd, w);
        int[] s = new int[total];
        if (rnd.nextInt(10) < 7) {
            for (int i = 0; i < total; i++) s[i] = c1;
        } else {
            int c2 = pickColor(rnd, w);
            int a = 1 + rnd.nextInt(total - 1);
            for (int i = 0; i < total; i++) s[i] = i < a ? c1 : c2;
        }
        return s;
    }

    // ---------- статическая оценка ----------

    static double staticEval(Board b, int clearN) {
        int free = b.freeCells();
        double s = 8.0 * free;
        for (int c = 0; c < b.n; c++) {
            int L = b.len[c];
            if (L == 0) continue;
            int runs = 1;
            for (int i = 1; i < L; i++) if (b.at(c, i) != b.at(c, i - 1)) runs++;
            int g = b.topGroup(c);
            s += 0.6 * g * g;            // чем больше группа сверху, тем ближе сгорание
            s -= 2.5 * (runs - 1);       // смешанные стопки неудобны
            if (runs == 1 && g < clearN) s += 1.0;
        }
        if (free == 0) s -= 300;
        return s;
    }
}
