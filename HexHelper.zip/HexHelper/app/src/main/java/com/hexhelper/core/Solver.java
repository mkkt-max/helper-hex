package com.hexhelper.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Перебор всех порядков и клеток для имеющихся в руке стопок (до 3 штук) —
 * выбирается последовательность с лучшей оценкой итогового поля.
 */
public final class Solver {
    public static final class Move {
        public final int slot;   // индекс стопки в руке
        public final int cell;   // индекс клетки на поле
        Move(int slot, int cell) { this.slot = slot; this.cell = cell; }
    }

    public static final class Plan {
        public final List<Move> moves = new ArrayList<>();
        public double score = Double.NEGATIVE_INFINITY;
        public int cleared;
    }

    private final int clearN;
    private final int[][] pieces;
    private Plan best;
    private final ArrayList<Move> cur = new ArrayList<>();

    private Solver(int[][] pieces, int clearN) {
        this.pieces = pieces;
        this.clearN = clearN;
    }

    /** pieces[i] — стопка снизу вверх, null — слот пуст. */
    public static Plan solve(Board board, int[][] pieces, int clearN) {
        Solver s = new Solver(pieces, clearN);
        s.best = new Plan();
        boolean[] used = new boolean[pieces.length];
        int avail = 0;
        for (int i = 0; i < pieces.length; i++) {
            if (pieces[i] == null) used[i] = true; else avail++;
        }
        if (avail == 0) return s.best;
        s.dfs(board, used, 0, 0, avail);
        return s.best;
    }

    private void dfs(Board b, boolean[] used, int depth, int cleared, int total) {
        if (depth == total) { consider(b, cleared, 0); return; }
        boolean any = false;
        for (int p = 0; p < pieces.length; p++) {
            if (used[p]) continue;
            for (int c = 0; c < b.n; c++) {
                if (!b.isEmpty(c)) continue;
                any = true;
                Board nb = b.copy();
                int cl = nb.place(c, pieces[p], clearN);
                used[p] = true;
                cur.add(new Move(p, c));
                dfs(nb, used, depth + 1, cleared + cl, total);
                cur.remove(cur.size() - 1);
                used[p] = false;
            }
        }
        if (!any) consider(b, cleared, total - depth);   // поле заполнено — проигрыш
    }

    private void consider(Board b, int cleared, int unplaced) {
        double s = evaluate(b, cleared, unplaced);
        if (s > best.score) {
            best.score = s;
            best.cleared = cleared;
            best.moves.clear();
            best.moves.addAll(cur);
        }
    }

    private double evaluate(Board b, int cleared, int unplaced) {
        double s = 100.0 * cleared;
        s += 8.0 * b.freeCells();
        for (int c = 0; c < b.n; c++) {
            int L = b.len[c];
            if (L == 0) continue;
            int runs = 1;
            for (int i = 1; i < L; i++) if (b.st[c][i] != b.st[c][i - 1]) runs++;
            int g = b.topGroup(c);
            s += 0.6 * g * g;            // чем больше группа сверху, тем ближе сгорание
            s -= 2.5 * (runs - 1);       // смешанные стопки неудобны
            if (runs == 1 && g < clearN) s += 1.0;
        }
        // потенциал слияния: соседние стопки с одним цветом наверху — это хорошо
        for (int a = 0; a < b.n; a++) {
            if (b.len[a] == 0) continue;
            for (int c : b.nbr[a]) {
                if (c < a || b.len[c] == 0) continue;
                if (b.top(a) == b.top(c)) s += 1.5;
            }
        }
        if (b.freeCells() == 0) s -= 300;
        if (unplaced > 0) s -= 2000.0 * unplaced;
        return s;
    }
}
