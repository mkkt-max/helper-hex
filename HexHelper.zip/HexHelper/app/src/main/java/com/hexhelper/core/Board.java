package com.hexhelper.core;

/**
 * Игровое поле: клетки со стопками плиток (снизу вверх) и соседство клеток.
 * Правила симуляции (как в Hexa Sort): после постановки стопки одинаковые верхние
 * группы соседних стопок сливаются в одну, а группа из clearN плиток сгорает.
 */
public final class Board {
    public static final int CAP = 64;

    public final int n;
    public final int[][] nbr;      // соседи (общие для всех копий)
    public final int[][] st;       // стопки: st[cell][0..len-1], снизу вверх
    public final int[] len;

    public Board(int n, int[][] nbr) {
        this.n = n;
        this.nbr = nbr;
        this.st = new int[n][CAP];
        this.len = new int[n];
    }

    public Board copy() {
        Board b = new Board(n, nbr);
        for (int i = 0; i < n; i++) {
            b.len[i] = len[i];
            System.arraycopy(st[i], 0, b.st[i], 0, len[i]);
        }
        return b;
    }

    public boolean isEmpty(int c) { return len[c] == 0; }

    public int top(int c) { return len[c] == 0 ? -1 : st[c][len[c] - 1]; }

    public int topGroup(int c) {
        if (len[c] == 0) return 0;
        int col = st[c][len[c] - 1], g = 0;
        for (int i = len[c] - 1; i >= 0 && st[c][i] == col; i--) g++;
        return g;
    }

    public int freeCells() {
        int f = 0;
        for (int i = 0; i < n; i++) if (len[i] == 0) f++;
        return f;
    }

    /** Ставит стопку в пустую клетку и разрешает слияния. Возвращает число сгоревших плиток. */
    public int place(int cell, int[] stack, int clearN) {
        len[cell] = 0;
        for (int v : stack) st[cell][len[cell]++] = v;
        return resolve(clearN);
    }

    private int resolve(int clearN) {
        int cleared = 0;
        for (int guard = 0; guard < 500; guard++) {
            boolean changed = false;
            for (int c = 0; c < n; c++) {
                int g = topGroup(c);
                if (g >= clearN) { len[c] -= g; cleared += g; changed = true; }
            }
            if (changed) continue;

            int ba = -1, bb = -1, bestSum = -1;
            for (int a = 0; a < n; a++) {
                if (len[a] == 0) continue;
                for (int b : nbr[a]) {
                    if (b < a || len[b] == 0 || top(a) != top(b)) continue;
                    int sum = topGroup(a) + topGroup(b);
                    if (sum > bestSum) { bestSum = sum; ba = a; bb = b; }
                }
            }
            if (ba < 0) break;
            int ga = topGroup(ba), gb = topGroup(bb);
            int donor, recv;
            if (ga < gb) { donor = ba; recv = bb; }
            else if (gb < ga) { donor = bb; recv = ba; }
            else if (len[ba] <= len[bb]) { donor = ba; recv = bb; }
            else { donor = bb; recv = ba; }
            int g = topGroup(donor), col = top(donor);
            len[donor] -= g;
            for (int i = 0; i < g && len[recv] < CAP; i++) st[recv][len[recv]++] = col;
        }
        return cleared;
    }
}
