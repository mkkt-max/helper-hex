package com.hexhelper.core;

/**
 * Игровое поле: клетки со стопками плиток (снизу вверх), закрытые клетки с ценой открытия
 * и очки. Правила симуляции:
 * - после постановки стопки одинаковые верхние группы соседей сливаются
 *   (одноцветная стопка принимает у смешанной; при равенстве принимает поставленная стопка);
 * - группа из clearN плиток сгорает и приносит очки (pts за плитку);
 * - когда очков набрано не меньше цены закрытой клетки, она открывается.
 * Класс рассчитан на миллионы вызовов: без выделения памяти внутри place().
 */
public final class Board {
    public static final int CAP = 32;
    public static final int NEVER = Integer.MAX_VALUE;

    public final int n;
    public final int[][] nbr;      // соседи (общие для всех копий)
    private final int[] st;        // st[c * CAP + i], снизу вверх
    public final int[] len;
    public final int[] price;      // 0 — клетка открыта; иначе цена открытия
    public int score;
    public int pts = 10;
    public long simCount;          // счётчик симулированных постановок (для отчёта)
    private int placed = -1;

    public Board(int n, int[][] nbr) {
        this.n = n;
        this.nbr = nbr;
        this.st = new int[n * CAP];
        this.len = new int[n];
        this.price = new int[n];
    }

    public Board copy() {
        Board b = new Board(n, nbr);
        b.copyFrom(this);
        return b;
    }

    /** Копирует состояние без выделения памяти. */
    public void copyFrom(Board o) {
        for (int i = 0; i < n; i++) {
            int L = o.len[i];
            len[i] = L;
            price[i] = o.price[i];
            System.arraycopy(o.st, i * CAP, st, i * CAP, L);
        }
        score = o.score; pts = o.pts; placed = o.placed;
    }

    public void setStack(int c, int[] s) {
        len[c] = Math.min(s.length, CAP);
        System.arraycopy(s, 0, st, c * CAP, len[c]);
    }

    public int at(int c, int i) { return st[c * CAP + i]; }
    public int top(int c) { return len[c] == 0 ? -1 : st[c * CAP + len[c] - 1]; }
    public boolean canPlace(int c) { return len[c] == 0 && price[c] == 0; }

    public int topGroup(int c) {
        int L = len[c];
        if (L == 0) return 0;
        int base = c * CAP, col = st[base + L - 1], g = 0;
        for (int i = L - 1; i >= 0 && st[base + i] == col; i--) g++;
        return g;
    }

    public boolean isPure(int c) {
        int base = c * CAP;
        for (int i = 1; i < len[c]; i++) if (st[base + i] != st[base]) return false;
        return true;
    }

    /** Число свободных открытых клеток. */
    public int freeCells() {
        int f = 0;
        for (int i = 0; i < n; i++) if (len[i] == 0 && price[i] == 0) f++;
        return f;
    }

    /** Ставит стопку в свободную клетку и разрешает слияния. Возвращает число сгоревших плиток. */
    public int place(int cell, int[] stack, int clearN) {
        simCount++;
        int base = cell * CAP;
        int L = Math.min(stack.length, CAP);
        System.arraycopy(stack, 0, st, base, L);
        len[cell] = L;
        placed = cell;
        return resolve(clearN);
    }

    private int resolve(int clearN) {
        int cleared = 0;
        for (int guard = 0; guard < 300; guard++) {
            boolean changed = false;
            int burned = 0;
            for (int c = 0; c < n; c++) {
                int g = topGroup(c);
                if (g >= clearN) { len[c] -= g; burned += g; changed = true; }
            }
            if (changed) {
                cleared += burned;
                score += burned * pts;
                for (int c = 0; c < n; c++) if (price[c] != 0 && score >= price[c]) price[c] = 0;
                continue;
            }

            int ba = -1, bb = -1, bestScore = -1;
            for (int a = 0; a < n; a++) {
                if (len[a] == 0) continue;
                int[] na = nbr[a];
                for (int k = 0; k < na.length; k++) {
                    int b = na[k];
                    if (b < a || len[b] == 0 || top(a) != top(b)) continue;
                    int sc = topGroup(a) + topGroup(b) + ((a == placed || b == placed) ? 1000 : 0);
                    if (sc > bestScore) { bestScore = sc; ba = a; bb = b; }
                }
            }
            if (ba < 0) break;
            boolean pa = isPure(ba), pb = isPure(bb);
            int donor, recv;
            if (pa != pb) { recv = pa ? ba : bb; donor = pa ? bb : ba; }
            else if (ba == placed) { recv = ba; donor = bb; }
            else if (bb == placed) { recv = bb; donor = ba; }
            else if (topGroup(ba) >= topGroup(bb)) { recv = ba; donor = bb; }
            else { recv = bb; donor = ba; }
            int g = topGroup(donor), col = top(donor);
            len[donor] -= g;
            for (int i = 0; i < g && len[recv] < CAP; i++) st[recv * CAP + len[recv]++] = col;
        }
        return cleared;
    }
}
