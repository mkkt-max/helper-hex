package com.hexhelper.core;

/**
 * Игровое поле: клетки со стопками плиток (снизу вверх) и соседство клеток.
 * Правила симуляции (как в Hexa Sort): после постановки стопки одинаковые верхние
 * группы соседних стопок сливаются в одну, а группа из clearN плиток сгорает.
 */
public final class Board {
    public static final int CAP = 64;

    public final int n;
    public final int[][] nbr;      // соседи (общие для всех копий)
    public final int[][] st;       // стопки: st[cell][0..len-1], снизу вверх
    public final int[] len;
    private int placed = -1;       // клетка, в которую только что поставили стопку

    public Board(int n, int[][] nbr) {
        this.n = n;
        this.nbr = nbr;
        this.st = new int[n][CAP];
        this.len = new int[n];
    }

    public Board copy() {
        Board b = new Board(n, nbr);
        b.placed = placed;
        for (int i = 0; i < n; i++) {
            b.len[i] = len[i];
            System.arraycopy(st[i], 0, b.st[i], 0, len[i]);
        }
        return b;
    }

    public boolean isEmpty(int c) { return len[c] == 0; }

    public int top(int c) { return len[c] == 0 ? -1 : st[c][len[c] - 1]; }

    public int topGroup(int c) {
        if (len[c] == 0) return 0;
        int col = st[c][len[c] - 1], g = 0;
        for (int i = len[c] - 1; i >= 0 && st[c][i] == col; i--) g++;
        return g;
    }

    public boolean isPure(int c) {
        for (int i = 1; i < len[c]; i++) if (st[c][i] != st[c][0]) return false;
        return true;
    }

    public int freeCells() {
        int f = 0;
        for (int i = 0; i < n; i++) if (len[i] == 0) f++;
        return f;
    }

    /** Ставит стопку в пустую клетку и разрешает слияния. Возвращает число сгоревших плиток. */
    public int place(int cell, int[] stack, int clearN) {
        len[cell] = 0;
        placed = cell;
        for (int v : stack) st[cell][len[cell]++] = v;
        return resolve(clearN);
    }

    private int resolve(int clearN) {
        int cleared = 0;
        for (int guard = 0; guard < 500; guard++) {
            boolean changed = false;
            for (int c = 0; c < n; c++) {
                int g = topGroup(c);
                if (g >= clearN) { len[c] -= g; cleared += g; changed = true; }
            }
            if (changed) continue;

            int ba = -1, bb = -1, bestScore = -1;
            for (int a = 0; a < n; a++) {
                if (len[a] == 0) continue;
                for (int b : nbr[a]) {
                    if (b < a || len[b] == 0 || top(a) != top(b)) continue;
                    int sc = topGroup(a) + topGroup(b) + ((a == placed || b == placed) ? 1000 : 0);
                    if (sc > bestScore) { bestScore = sc; ba = a; bb = b; }
                }
            }
            if (ba < 0) break;
            // кто принимает плитки: чистая (одноцветная) стопка принимает у смешанной;
            // при равенстве принимает только что поставленная стопка, иначе — большая группа
            boolean pa = isPure(ba), pb = isPure(bb);
            int donor, recv;
            if (pa != pb) { recv = pa ? ba : bb; donor = pa ? bb : ba; }
            else if (ba == placed) { recv = ba; donor = bb; }
            else if (bb == placed) { recv = bb; donor = ba; }
            else if (topGroup(ba) >= topGroup(bb)) { recv = ba; donor = bb; }
            else { recv = bb; donor = ba; }
            int g = topGroup(donor), col = top(donor);
            len[donor] -= g;
            for (int i = 0; i < g && len[recv] < CAP; i++) st[recv][len[recv]++] = col;
        }
        return cleared;
    }
}
