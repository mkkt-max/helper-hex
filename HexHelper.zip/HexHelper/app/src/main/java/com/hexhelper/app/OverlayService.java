package com.hexhelper.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hexhelper.core.Solver;
import com.hexhelper.core.Vision;

import java.nio.ByteBuffer;

/**
 * Передний план: захват экрана (MediaProjection) + плавающая панель + прозрачный оверлей.
 * По нажатию «Подсказка» оверлей прячется, делается кадр, поле распознаётся, считается лучший
 * порядок ходов и поверх игры рисуются стрелки.
 */
public class OverlayService extends Service {
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";
    public static final String ACTION_STOP = "com.hexhelper.STOP";
    private static final String CHANNEL = "hexhelper";

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread workerThread;
    private Handler worker;

    private WindowManager wm;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private int sw, sh, dpi;

    private OverlayView overlay;
    private LinearLayout panel;
    private TextView btnHint, btnAuto;
    private WindowManager.LayoutParams panelLp;
    private Prefs prefs;

    private View watcher;
    private boolean busy = false;
    private boolean auto = true;
    private boolean pendingAgain = false;

    /** После касания игры ждём окончания анимаций слияния и пересчитываем подсказку. */
    private final Runnable autoRun = new Runnable() {
        @Override public void run() {
            if (!auto) return;
            if (busy) { pendingAgain = true; return; }
            analyze();
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;     // уже запущено

        startForegroundCompat();
        prefs = new Prefs(this);
        auto = prefs.auto();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        workerThread = new HandlerThread("hexhelper-worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), intent.getParcelableExtra(EXTRA_DATA));
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(OverlayService.this::stopSelf); }
        }, main);

        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi;
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("hexhelper", sw, sh, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

        addOverlay();
        addPanel();
        addTouchWatcher();
        if (auto) main.postDelayed(autoRun, 700);   // первая подсказка сразу после запуска
        return START_NOT_STICKY;
    }

    // ---------- окна ----------

    private void addOverlay() {
        overlay = new OverlayView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(overlay, lp);
    }

    private void addPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xAA000000);
        btnHint = button("💡 Подсказка");
        btnAuto = button(auto ? "Авто: вкл" : "Авто: выкл");
        TextView btnClear = button("Скрыть");
        TextView btnStop = button("Стоп");
        panel.addView(btnHint); panel.addView(btnAuto); panel.addView(btnClear); panel.addView(btnStop);

        btnHint.setOnClickListener(v -> analyze());
        btnAuto.setOnClickListener(v -> {
            auto = !auto;
            prefs.putBool("auto", auto);
            btnAuto.setText(auto ? "Авто: вкл" : "Авто: выкл");
            main.removeCallbacks(autoRun);
            if (auto) main.post(autoRun);
        });
        btnClear.setOnClickListener(v -> overlay.clear());
        btnStop.setOnClickListener(v -> stopSelf());

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = 0;
        panelLp.y = (int) (sh * 0.62f);     // у нижней части экрана, не закрывает поле
        wm.addView(panel, panelLp);
        makeDraggable(btnHint);             // тянуть панель можно за верхнюю кнопку (долгое нажатие не нужно)
    }

    /** Окно 1x1 px, которое получает ACTION_OUTSIDE при любом касании вне него — так видим ход игрока. */
    private void addTouchWatcher() {
        watcher = new View(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        watcher.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE && auto && !busy) {
                main.removeCallbacks(autoRun);
                main.postDelayed(autoRun, 2200);    // подождать анимацию слияния
            }
            return false;
        });
        wm.addView(watcher, lp);
    }

    private TextView button(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        int p = (int) (10 * getResources().getDisplayMetrics().density);
        t.setPadding(p, p, p, p);
        return t;
    }

    /** Перетаскивание панели; короткое касание без смещения остаётся обычным нажатием. */
    private void makeDraggable(View handle) {
        final int[] st = new int[4];
        final boolean[] moved = {false};
        handle.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    st[0] = panelLp.x; st[1] = panelLp.y; st[2] = (int) e.getRawX(); st[3] = (int) e.getRawY();
                    moved[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) e.getRawX() - st[2], dy = (int) e.getRawY() - st[3];
                    if (Math.abs(dx) + Math.abs(dy) > 20) moved[0] = true;
                    if (moved[0]) { panelLp.x = st[0] + dx; panelLp.y = st[1] + dy; wm.updateViewLayout(panel, panelLp); }
                    return moved[0];
                case MotionEvent.ACTION_UP:
                    return moved[0];
                default:
                    return false;
            }
        });
    }

    // ---------- анализ ----------

    private void analyze() {
        if (busy) return;
        busy = true;
        overlay.setVisibility(View.INVISIBLE);   // наши подсказки не должны попасть в кадр
        panel.setVisibility(View.INVISIBLE);
        main.postDelayed(() -> grabFrame(0), 260);
    }

    private void grabFrame(int attempt) {
        Image img = null;
        try { img = reader.acquireLatestImage(); } catch (Exception ignored) {}
        if (img == null) {
            if (attempt < 8) { main.postDelayed(() -> grabFrame(attempt + 1), 120); return; }
            finishCapture("Не удалось получить кадр экрана");
            return;
        }
        final int[] pixels;
        try {
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rowStride = pl.getRowStride(), pixStride = pl.getPixelStride();
            Bitmap bmp = Bitmap.createBitmap(rowStride / pixStride, sh, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            pixels = new int[sw * sh];
            bmp.getPixels(pixels, 0, sw, 0, 0, sw, sh);
            bmp.recycle();
        } finally { img.close(); }
        // кадр получен — возвращаем интерфейс сразу, а считаем в фоне
        overlay.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        overlay.setResult(null, null, prefs.calib(), sw, false, "Считаю…");   // старые стрелки уже неактуальны
        final Vision.Calib calib = prefs.calib();
        final Solver.Params prm = new Solver.Params();
        prm.clearN = prefs.clearN();
        prm.budgetMs = prefs.budgetSec() * 1000L;
        prm.rounds = prefs.rounds();
        final boolean debug = prefs.debug();
        worker.post(() -> {
            Vision.Scene sc = Vision.analyze(pixels, sw, sh, calib);
            int pieces = sc.hand.length;
            String msg;
            Solver.Plan plan = null;
            if (sc.playable.size() < 3) msg = "Поле не найдено — откройте уровень или поправьте калибровку";
            else if (pieces == 0) msg = "Нет стопок в руке";
            else {
                plan = Solver.solve(sc.board, sc.hand, prm);
                if (plan.moves.isEmpty()) msg = "Нет доступных ходов";
                else {
                    msg = "Сгорит: " + plan.cleared + " · просчитано " + fmt(plan.simulated) + " ходов";
                    if (plan.unlocks) msg += " · откроет замок";
                    if (sc.score >= 0) msg += " · очки " + sc.score;
                }
            }
            final Solver.Plan fp = plan; final String fm = msg;
            main.post(() -> {
                overlay.setResult(sc, fp, calib, sw, debug, fm);
                busy = false;
                if (pendingAgain) { pendingAgain = false; main.postDelayed(autoRun, 300); }
            });
        });
    }

    private static String fmt(long n) {
        if (n >= 1_000_000) return String.format(java.util.Locale.US, "%.1f млн", n / 1e6);
        if (n >= 1000) return (n / 1000) + " тыс.";
        return String.valueOf(n);
    }

    private void finishCapture(String msg) {
        overlay.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        overlay.setResult(null, null, prefs.calib(), sw, false, msg);
        busy = false;
    }

    // ---------- служебное ----------

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Hex Helper", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = b.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Hex Helper работает")
                .setContentText("Нажмите, чтобы остановить")
                .setContentIntent(pi).build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);
    }

    @Override
    public void onDestroy() {
        auto = false;
        main.removeCallbacksAndMessages(null);
        try { if (watcher != null) wm.removeView(watcher); } catch (Exception ignored) {}
        try { if (overlay != null) wm.removeView(overlay); } catch (Exception ignored) {}
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (workerThread != null) workerThread.quitSafely();
        super.onDestroy();
    }
}
