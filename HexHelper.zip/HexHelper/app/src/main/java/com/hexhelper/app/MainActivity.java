package com.hexhelper.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** Настройка: разрешение на оверлей, запрос захвата экрана, калибровка. */
public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);

        int p = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        TextView info = new TextView(this);
        info.setText("Hex Helper — подсказки для игры со стопками шестиугольников.\n\n"
                + "1) Разрешите показ поверх других окон.\n"
                + "2) Нажмите «Запустить» и разрешите запись экрана.\n"
                + "3) Откройте игру и нажмите «💡 Подсказка» на плавающей панели: появятся стрелки и номера ходов.\n\n"
                + "Приложение только смотрит на экран и рисует подсказки, в игру ничего не нажимает.");
        root.addView(info);

        Button overlayBtn = new Button(this);
        overlayBtn.setText("1. Разрешить поверх экрана");
        overlayBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        root.addView(overlayBtn);

        Button startBtn = new Button(this);
        startBtn.setText("2. Запустить помощника");
        startBtn.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала разрешите показ поверх экрана", Toast.LENGTH_LONG).show();
                return;
            }
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        root.addView(startBtn);

        Button stopBtn = new Button(this);
        stopBtn.setText("Остановить");
        stopBtn.setOnClickListener(v -> startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP)));
        root.addView(stopBtn);

        TextView cal = new TextView(this);
        cal.setText("\nКалибровка (если стрелки смещены относительно клеток)");
        root.addView(cal);
        addSeek(root, "Масштаб, %", "scalePct", 90, 110, prefs.scalePct());
        addSeek(root, "Сдвиг по X", "offX", -100, 100, prefs.offX());
        addSeek(root, "Сдвиг по Y", "offY", -150, 150, prefs.offY());
        addSeek(root, "Плиток для сгорания", "clearN", 5, 15, prefs.clearN());
        addSeek(root, "Очков за сгоревшую плитку", "pts", 1, 30, prefs.ptsPerTile());

        TextView la = new TextView(this);
        la.setText("\nВзгляд вперёд");
        root.addView(la);
        addSeek(root, "Время расчёта, сек", "budgetSec", 1, 10, prefs.budgetSec());
        addSeek(root, "Раундов вперёд (по 3 стопки)", "rounds", 1, 8, prefs.rounds());

        TextView lo = new TextView(this);
        lo.setText("\nЗакрытые клетки и очки");
        root.addView(lo);
        addText(root, "Цены замков через запятую (слева направо)", "locks", prefs.lockPricesText(), false);
        addText(root, "Число у сундука (полная полоска)", "target", String.valueOf(prefs.scoreTarget()), true);

        CheckBox dbg = new CheckBox(this);
        dbg.setText("Отладка: показывать, что распознано (цвета и высоту стопок)");
        dbg.setChecked(prefs.debug());
        dbg.setOnCheckedChangeListener((v, c) -> prefs.putBool("debug", c));
        root.addView(dbg);
    }

    private void addText(LinearLayout root, String label, String key, String value, boolean number) {
        TextView t = new TextView(this);
        t.setText(label);
        android.widget.EditText e = new android.widget.EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        if (number) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                String v = s.toString().trim();
                if (number) {
                    try { prefs.putInt(key, Integer.parseInt(v)); } catch (NumberFormatException ignored) {}
                } else prefs.putString(key, v);
            }
        });
        root.addView(t);
        root.addView(e);
    }

    private void addSeek(LinearLayout root, String label, String key, int min, int max, int value) {
        final TextView t = new TextView(this);
        t.setText(label + ": " + value);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                prefs.putInt(key, prog + min);
                t.setText(label + ": " + (prog + min));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(t);
        root.addView(sb);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, OverlayService.class);
                i.putExtra(OverlayService.EXTRA_CODE, res);
                i.putExtra(OverlayService.EXTRA_DATA, data);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                Toast.makeText(this, "Запущено. Откройте игру и нажмите «Подсказка»", Toast.LENGTH_LONG).show();
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Без разрешения на запись экрана работать нечем", Toast.LENGTH_LONG).show();
            }
        }
    }
}
