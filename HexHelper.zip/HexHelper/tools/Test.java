import com.hexhelper.core.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;

public class Test {
    static String str(int[] s) {
        StringBuilder sb = new StringBuilder();
        for (int v : s) sb.append(HexColor.NAMES[v]);
        return sb.toString();
    }

    public static void main(String[] a) throws Exception {
        BufferedImage im = ImageIO.read(new File(a[0]));
        int w = im.getWidth(), h = im.getHeight();
        int[] px = im.getRGB(0, 0, w, h, null, 0, w);
        Vision.Scene sc = Vision.analyze(px, w, h, new Vision.Calib());
        System.out.println("cells: playable=" + sc.playable.size() + " grid=" + sc.grid.size());
        for (Vision.Cell c : sc.grid) {
            String t = c.type == Vision.T_EMPTY ? "empty" : c.type == Vision.T_LOCKED ? "LOCKED" : "stack " + str(c.stack);
            System.out.printf("  j=%d k=%d id=%d (%.0f,%.0f) %s%n", c.j, c.k, c.id, c.x, c.y, t);
        }
        for (int i = 0; i < sc.hand.length; i++)
            System.out.println("hand " + i + " x=" + sc.handX[i] + ": " + str(sc.hand[i]) + " (" + sc.hand[i].length + ")");
        long t0 = System.nanoTime();
        Solver.Plan p = Solver.solve(sc.board, sc.hand, a.length > 1 ? Integer.parseInt(a[1]) : 10);
        System.out.printf("solve: %.1f ms, score=%.1f cleared=%d%n", (System.nanoTime() - t0) / 1e6, p.score, p.cleared);
        int step = 1;
        for (Solver.Move m : p.moves) {
            Vision.Cell c = sc.playable.get(m.cell);
            System.out.printf("  %d) hand slot %d (%s) -> cell j=%d k=%d (%.0f,%.0f)%n", step++, m.slot + 1, str(sc.hand[m.slot]), c.j, c.k, c.x, c.y);
        }
    }
}
